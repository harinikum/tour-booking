<?php
$modelsPath = '../../../../models/put.php';
$headersPath = '../../../../config/header.php';

// Ensure required files exist
if (!file_exists($modelsPath) || !file_exists($headersPath)) {
    handleResponse(500, 'Required files are missing');
    exit();
}

require_once $modelsPath;
require_once $headersPath;

function handleResponse($statusCode, $message) {
    http_response_code($statusCode);
    echo json_encode(['error' => $message]);
    exit();
}

// Accept both PUT and POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'PUT' && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    handleResponse(405, "Method Not Allowed");
}

// Read JSON data from request body
$rawData = file_get_contents('php://input');
$data = json_decode($rawData, true);

// Debug: Log the raw input data
error_log("Raw input data: " . $rawData);

// If JSON is empty, check for form-data (POST)
if ($data === null) {
    $data = $_POST; // Handles form-data submission
}

// Debug: Log the $data array
error_log("Data array: " . print_r($data, true));

// Ensure email exists
if (!isset($data['email']) || empty($data['email'])) {
    handleResponse(400, "Email is required");
}

// Initialize the Put object
$obj = new Put();
$result = $obj->updatelogindetail($data);

// Return JSON response
echo json_encode($result);
?>