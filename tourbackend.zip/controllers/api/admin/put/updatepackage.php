<?php

// Define file paths
$modelsPath = '../../../../models/put.php';
$headersPath = '../../../../config/header.php';

// Check if required files exist
if (!file_exists($modelsPath) || !file_exists($headersPath)) {
    handleResponse(500, 'Required files are missing');
}

// Include necessary files
require_once $modelsPath;
require_once $headersPath;

// Function to handle errors and send response
function handleResponse($statusCode, $message) {
    http_response_code($statusCode);
    echo json_encode(['error' => $message]);
    exit();
}

// Decode incoming JSON data
$data = json_decode(file_get_contents('php://input'));

// Check if the required fields are provided
if (!isset($data->id) || !isset($data->packname) || !isset($data->city) || !isset($data->price) ) {
    handleResponse(400, 'All required fields (id, packname, city,price) are required');
}


$obj = new Put();

$data = json_decode(file_get_contents('php://input'));
if (isset($data->id, $data->packname, $data->city, $data->price)) {
    $result = $obj->updatepackage(
        $data->id, 
        $data->packname, 
        $data->city, 
        $data->price, 
    );
    echo json_encode($result);
} else {
    http_response_code(400);
    echo json_encode(["error" => "Invalid input"]);
}



echo json_encode($result);
?>
