<?php
include_once '../../../../config/database.php';

class Post
{
    public $conn;
    public $response;

    function __construct()
    {
        $db = new Database();
        $this->conn = $db->connect();
    }
    
   


    public function Register($username,$email,$password)
    {
         $insert = "INSERT INTO register(username,email,password)  VALUES (?,?, ?)";
         $stmt = mysqli_prepare($this->conn, $insert);
 
         if (!$stmt) {
             return ["message" => "Query preparation error: " . mysqli_error($this->conn)];
         }
 
         mysqli_stmt_bind_param($stmt, "sss", $username,$email,$password);
         $result = mysqli_stmt_execute($stmt);
 
         if ($result) {
             return ["message" => "User Register successfully"];
         } else {
             return ["message" => "Product insertion failed"];
         }
    }
    public function A_InsertPlans2($name,$password)
    {
        $insert = "INSERT INTO admin(name, password) VALUES ( ?, ?)";
        $stmt = mysqli_prepare($this->conn, $insert);
    
        if (!$stmt) {
            return ["message" => "Query preparation error: " . mysqli_error($this->conn)];
        }
    
        mysqli_stmt_bind_param($stmt, "ss", $name,$password);
        $result = mysqli_stmt_execute($stmt);
    
        if ($result) {
            return ["message" => "Plan Added successful"];
        } else {
            return ["message" => "Plan Added failed: " . mysqli_error($this->conn)];
        }
    }
    public function book($id, $name, $email, $phone, $arrival_date, $departure, $number_of_days, $price, $status) {
        // Corrected SQL query
        $insert = "INSERT INTO booking (id, name, email, phone, arrival_date, departure, number_of_days, price, status) 
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($this->conn, $insert);
    
        if (!$stmt) {
            return ["message" => "Query preparation error: " . mysqli_error($this->conn)];
        }
    
        // Bind parameters to the query with correct type specifiers
        // The ? placeholders are for all fields, including the id (which might be auto-incremented).
        mysqli_stmt_bind_param($stmt, "isssssiss", $id, $name, $email, $phone, $arrival_date, $departure, $number_of_days, $price, $status);
    
        $result = mysqli_stmt_execute($stmt);
    
        if ($result) {
            return ["message" => "Booking added successfully"];
        } else {
            return ["message" => "Booking failed: " . mysqli_error($this->conn)];
        }
    }
    
    
    

public function images($packname, $city, $price, $file)
{
    $advertisementQuery = "INSERT INTO roomimage (packname, city, price, file) VALUES (?, ?, ?, ?)";
    $stmtadvertisement = mysqli_prepare($this->conn, $advertisementQuery);

    if (!$stmtadvertisement) {
        return "Failed to prepare SQL statement: " . mysqli_error($this->conn);
    }

    mysqli_stmt_bind_param($stmtadvertisement, 'ssss', $packname, $city, $price, $file);
    $advertisementExec = mysqli_stmt_execute($stmtadvertisement);

    if ($advertisementExec) {
        return "Package added successfully";
    } else {
        return "Failed to insert data into database: " . mysqli_error($this->conn);
    }
}

























 





}
?> 
