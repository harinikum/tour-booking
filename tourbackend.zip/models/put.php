<?php
include_once '../../../../config/database.php';

class Put
{
    public $conn;
    public $response;

    function __construct()
    {
        $db = new Database();
        $this->conn = $db->connect();
    }

  

    public function book($id, $name, $email, $phone, $arrival_date, $departure, $number_of_days, $price, $status)
{
    $id = (int)$id; 
    $number_of_days = (int)$number_of_days;

    $checkUserQuery = "SELECT * FROM booking WHERE id = ?";
    $checkUserStmt = mysqli_prepare($this->conn, $checkUserQuery);
    mysqli_stmt_bind_param($checkUserStmt, "i", $id); 
    mysqli_stmt_execute($checkUserStmt);
    $checkUserResult = mysqli_stmt_get_result($checkUserStmt);

    if (mysqli_num_rows($checkUserResult) == 1) {
        // User exists, proceed with update
        $updateQuery = "
            UPDATE booking
            SET 
                name = ?, 
                email = ?, 
                phone = ?, 
                arrival_date = ?,
                departure = ?,
                number_of_days = ?,
                price = ?,
                status = ? 
            WHERE 
                id = ?
        ";
        $updateStmt = mysqli_prepare($this->conn, $updateQuery);

        // Bind the parameters correctly
        mysqli_stmt_bind_param(
            $updateStmt, 
            "sssssissi", // Correct parameter types: 7 strings + 1 integer
            $name, 
            $email, 
            $phone, 
            $arrival_date, 
            $departure, 
            $number_of_days, 
            $price,
            $status,
            $id
        );

        if (mysqli_stmt_execute($updateStmt)) {
            http_response_code(200);
            return ["message" => "User details updated successfully"];
        } else {
            http_response_code(500);
            return ["error" => "Error updating user details"];
        }
    } else {
        http_response_code(404);
        return ["error" => "User not found"];
    }
}  
  public function updatepackage($id, $packname, $city, $price) {
    $query = "UPDATE roomimage 
              SET packname = ?, city = ?, price = ?
              WHERE id = ?";

    $stmt = $this->conn->prepare($query);

    if (!$stmt) {
        return [
            "success" => false,
            "message" => "Prepare failed: " . $this->conn->error
        ];
    }

    // Bind parameters safely
    $stmt->bind_param("ssdi", $packname, $city, $price, $id);

    if ($stmt->execute()) {
        return [
            "success" => true,
            "message" => "Package updated successfully"
        ];
    } else {
        return [
            "success" => false,
            "message" => "Failed to update package: " . $stmt->error
        ];
    }
}

public function updatelogindetail($data) {
        $email = $data['email']; 

        if (!$this->conn) {
            return ["error" => "Database connection error: " . mysqli_connect_error()];
        }

        $status = isset($data['status']) && $data['status'] == 1 ? 1 : 0;
      
        $query = "UPDATE register SET status = ? WHERE email = ?";
        $stmt = mysqli_prepare($this->conn, $query);
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "is", $status, $email);
            if (mysqli_stmt_execute($stmt)) {
                return ["message" => "Update successful"];
            } else {
                return ["error" => "Failed to update record"];
            }
        } else {
            return ["error" => "SQL statement preparation failed"];
        }
    }
  
}
?>